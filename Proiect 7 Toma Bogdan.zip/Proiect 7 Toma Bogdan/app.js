// Demo data
const user = {name:'Andrei Popescu'};
const accounts = [
  { id:'RON-1', type:'Curent', balance:5243.45, IBAN:'RO09BNCC000000000001' },
  { id:'SAV-1', type:'Economii', balance:12000.00, interest:6, IBAN:'RO09BNCC000000000002' },
  { id:'FX-1', type:'Valută USD', balance:1500.50, IBAN:'RO09BNCC000000000003' },
  { id:'CR-1', type:'Credit', balance:-4000.00, IBAN:'RO09BNCC000000000004', limit:10000 }
];

const cards = [
  { type:'Visa', number:'1234', valid:'12/26', status:'Activ', contactless:500, atm:2000 },
  { type:'Mastercard', number:'5678', valid:'05/27', status:'Activ', contactless:700, atm:1500 },
  { type:'Visa Electron', number:'9012', valid:'08/25', status:'Blocat', contactless:300, atm:1000 }
];

const offers = [
  { category:'Depozit', name:'Depozit Flex 6% / 12 luni', min:1000, btn:'Deschide depozit' },
  { category:'Credit', name:'Credit personal promo', info:'Documentație minimă', btn:'Simulează credit' },
  { category:'Investiții', name:'Fond mutual Acțiuni', info:'Randament estimat 8%', btn:'Detalii' }
];

const bankInfo = {
  name:'BogBank S.A. (demo)',
  taxCode:'RO00000000',
  address:'Str. Exemplu 1, București',
  license:'Autoritate financiară (demo)',
  filiale:[
    { city:'București', addr:'Bd. Demo 10', hours:'L‑V 09:00‑18:00' },
    { city:'Cluj', addr:'Str. Exemplu 2', hours:'L‑V 09:00‑17:00' },
    { city:'Iași', addr:'Str. Demo 3', hours:'L‑V 09:00‑17:00' }
  ],
  support:[
    { method:'Telefon', info:'+40 21 000 000' },
    { method:'Email', info:'suport@bogbank.demo' },
    { method:'Chat', info:'Chat demo în interfață' }
  ]
};

const faqItems = [
  { q:'Cum blochez cardul?', a:'Din secțiunea Carduri — click pe "Blochează card" sau sună la +40 21 000 000.' },
  { q:'Care sunt limitele de retragere?', a:'Limitele sunt afișate în pagina Carduri și pot fi modificate la cerere.' },
  { q:'Cum setez plăți recurente?', a:'Din Plăți & Transfer: alege beneficiarul și activează opțiunea recurente.' },
  { q:'Cum pot solicita extrase bancare?', a:'În secțiunea Conturi, click pe "Descarcă extras".' },
  { q:'Cum activez notificările push?', a:'În Setări → Preferințe → Activează notificări.' }
];

// Utils
function formatMoney(x){ return x.toLocaleString('ro-RO',{style:'currency',currency:'RON'}); }

// Theme toggle
document.getElementById('themeToggle').addEventListener('click',()=>{ document.body.classList.toggle('light'); });

// Navigation
document.querySelectorAll('.nav button').forEach(btn=>{
  btn.addEventListener('click',()=>{
    document.querySelectorAll('.nav button').forEach(b=>b.classList.remove('active'));
    btn.classList.add('active');
    const view = btn.dataset.view;
    document.querySelectorAll('main section').forEach(s=>s.style.display='none');
    document.getElementById('view-'+view).style.display='block';
  });
});

// Init user
document.getElementById('userName').textContent = user.name;

// Populate accounts
const accountsContainer = document.getElementById('accountsContainer');
accounts.forEach(acc=>{
  const div = document.createElement('div'); div.className='card';
  div.innerHTML=`<div class="muted small">${acc.type}</div>
                 <div class="amount">${formatMoney(acc.balance)}</div>
                 <div class="muted small">IBAN: ${acc.IBAN}</div>
                 ${acc.interest?`<div class="muted small">Dobândă: ${acc.interest}%</div>`:''}
                 ${acc.limit?`<div class="muted small">Limită credit: ${formatMoney(acc.limit)}</div>`:''}`;
  accountsContainer.appendChild(div);
});

// Populate cards
const cardsContainer = document.getElementById('cardsContainer');
cards.forEach(c=>{
  const div = document.createElement('div'); div.className='card';
  div.innerHTML=`<div class="muted small">${c.type} • **** ${c.number}</div>
                 <div class="muted small">Valid: ${c.valid} • Status: ${c.status}</div>
                 <div class="small muted">Contactless: ${formatMoney(c.contactless)}, ATM: ${formatMoney(c.atm)}</div>`;
  cardsContainer.appendChild(div);
});

// Populate offers
const offersContainer = document.getElementById('offersContainer');
offers.forEach(o=>{
  const div = document.createElement('div'); div.className='offer';
  div.innerHTML=`<div class="small muted">${o.category}</div>
                 <div style="font-weight:600">${o.name}</div>
                 ${o.info?`<div class="muted small">${o.info}</div>`:''}
                 <button class="btn btn-primary" style="margin-top:6px">${o.btn}</button>`;
  offersContainer.appendChild(div);
});

// Populate Despre
const bankDiv = document.getElementById('bankInfo');
bankDiv.innerHTML=`<div>Nume: ${bankInfo.name}</div>
                   <div>CUI: ${bankInfo.taxCode}</div>
                   <div>Adresă: ${bankInfo.address}</div>
                   <div>Licență: ${bankInfo.license}</div>
                   <div>Filiale:</div>
                   <ul>${bankInfo.filiale.map(f=>`<li>${f.city}: ${f.addr} (${f.hours})</li>`).join('')}</ul>
                   <div>Suport:</div>
                   <ul>${bankInfo.support.map(s=>`<li>${s.method}: ${s.info}</li>`).join('')}</ul>`;

// Populate FAQ
const faqContainer = document.getElementById('faqContainer');
faqItems.forEach(f=>{
  const div = document.createElement('div'); div.className='faq-item';
  div.innerHTML=`<div class="faq-q">${f.q}</div><div class="faq-a muted" style="display:none;margin-top:4px">${f.a}</div>`;
  div.querySelector('.faq-q').addEventListener('click',()=>{ 
    const a = div.querySelector('.faq-a'); 
    a.style.display=a.style.display==='none'?'block':'none'; 
  });
  faqContainer.appendChild(div);
});

// Dashboard totals
document.getElementById('totalBalance').textContent = formatMoney(accounts.reduce((s,a)=>s+a.balance,0));
document.getElementById('dashboardAccounts').textContent = accounts.map(a=>a.type).join(' • ');
document.getElementById('lastUpdate').textContent = new Date().toLocaleString('ro-RO');

// Simple chart
const ctx = document.getElementById('balanceChart').getContext('2d');
ctx.fillStyle='#0b1220'; ctx.fillRect(0,0,800,220);
ctx.fillStyle='#06b6d4';
let x=0; accounts.forEach(a=>{
  ctx.fillRect(x, 220 - (a.balance/50000*200), 60, a.balance/50000*200);
  x+=80;
});

// Dashboard summary
const dashboardCards = document.getElementById('dashboardCards'); dashboardCards.innerHTML='<h4>Carduri rapide</h4>'; 
cards.forEach(c=>{ 
  const d=document.createElement('div'); d.className='small muted-plain'; 
  d.textContent=`${c.type} ****${c.number} (${c.status})`; 
  dashboardCards.appendChild(d);
});
const dashboardOffers = document.getElementById('dashboardOffers'); dashboardOffers.innerHTML='<h4>Oferte</h4>';
offers.forEach(o=>{
  const d=document.createElement('div'); d.className='small muted-plain'; d.textContent=`${o.name} (${o.category})`;
  dashboardOffers.appendChild(d);
});
const dashboardQuickActions = document.getElementById('dashboardQuickActions'); 
dashboardQuickActions.innerHTML='<h4>Acțiuni rapide</h4><button class="btn btn-primary">Transfer rapid</button>';
