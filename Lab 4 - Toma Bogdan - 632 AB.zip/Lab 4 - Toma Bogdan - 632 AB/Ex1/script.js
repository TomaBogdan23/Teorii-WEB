// Selectăm elementele din DOM
const inputActivitate = document.getElementById('inputActivitate');
const btnAdauga = document.getElementById('btnAdauga');
const listaActivitati = document.getElementById('listaActivitati');

// Definim tabloul cu lunile anului în limba română
const luni = [
    "Ianuarie", "Februarie", "Martie", "Aprilie", "Mai", "Iunie",
    "Iulie", "August", "Septembrie", "Octombrie", "Noiembrie", "Decembrie"
];

// Adăugăm ascultătorul de evenimente pentru click pe buton
btnAdauga.addEventListener('click', function() {
    // 1. Citim textul introdus și eliminăm spațiile goale de la început/sfârșit
    const textActivitate = inputActivitate.value.trim();

    // 2. Verificăm dacă textul nu este gol
    if (textActivitate !== "") {
        
        // 3. Obținem data curentă
        const dataCurenta = new Date();
        const ziua = dataCurenta.getDate();
        const anul = dataCurenta.getFullYear();
        const indexLuna = dataCurenta.getMonth(); // Returnează 0-11
        
        // Obținem numele lunii din tablou
        const numeLuna = luni[indexLuna];

        // 4. Creăm noul element <li>
        const elementNou = document.createElement('li');

        // 5. Construim textul final
        // Format: Activitate – adăugată la: 16 Noiembrie 2025
        elementNou.textContent = `${textActivitate} – adăugată la: ${ziua} ${numeLuna} ${anul}`;

        // 6. Adăugăm elementul în listă
        listaActivitati.appendChild(elementNou);

        // 7. Golim câmpul de input pentru următoarea activitate
        inputActivitate.value = "";
        
        // Opțional: Punem focusul înapoi pe input
        inputActivitate.focus();
    } else {
        alert("Te rog introdu o activitate validă!");
    }
});