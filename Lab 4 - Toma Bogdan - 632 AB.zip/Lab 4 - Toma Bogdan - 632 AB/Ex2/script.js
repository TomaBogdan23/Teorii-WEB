// Așteptăm încărcarea completă a DOM-ului (recomandat, deși scriptul e la final)
document.addEventListener("DOMContentLoaded", function() {
    
    // 1. Selectăm elementele necesare
    const divDetalii = document.getElementById("detalii");
    const btnDetalii = document.getElementById("btnDetalii");
    const spanData = document.getElementById("dataProdus");

    // ---------------------------------------------------------
    // SARCINA A: La încărcarea paginii
    // ---------------------------------------------------------

    // Adăugăm clasa .ascuns pentru ca detaliile să nu fie vizibile inițial
    divDetalii.classList.add("ascuns");

    // Obținem data curentă
    const dataCurenta = new Date();
    
    // Tabloul de luni (pentru a afișa luna text)
    const luni = [
        "Ianuarie", "Februarie", "Martie", "Aprilie", "Mai", "Iunie",
        "Iulie", "August", "Septembrie", "Octombrie", "Noiembrie", "Decembrie"
    ];

    // Extragem ziua, luna (index) și anul
    const zi = dataCurenta.getDate();
    const lunaText = luni[dataCurenta.getMonth()];
    const an = dataCurenta.getFullYear();

    // Construim șirul și îl injectăm în span-ul #dataProdus
    spanData.textContent = `${zi} ${lunaText} ${an}`;

    // ---------------------------------------------------------
    // SARCINA B: La click pe buton
    // ---------------------------------------------------------
    
    btnDetalii.addEventListener("click", function() {
        // Comutăm clasa "ascuns" (dacă există o scoate, dacă nu există o pune)
        divDetalii.classList.toggle("ascuns");

        // Verificăm starea curentă pentru a schimba textul butonului
        if (divDetalii.classList.contains("ascuns")) {
            // Dacă detaliile sunt acum ascunse
            btnDetalii.textContent = "Afișează detalii";
        } else {
            // Dacă detaliile sunt acum vizibile
            btnDetalii.textContent = "Ascunde detalii";
        }
    });

});